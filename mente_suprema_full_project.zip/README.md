# Mente Suprema QI - Full Project
This repo contains frontend + database scripts to deploy Mente Suprema QI using GitHub + Vercel + Supabase.
See the database folder for schema, seed and RLS policy files.
