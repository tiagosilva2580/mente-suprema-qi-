-- rls_policies.sql
-- Enable Row Level Security and create safe policies for Supabase style auth (auth.jwt())
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS select_users ON users;
DROP POLICY IF EXISTS insert_users ON users;
DROP POLICY IF EXISTS update_users ON users;
DROP POLICY IF EXISTS delete_users ON users;
CREATE POLICY select_users ON users FOR SELECT USING (auth.jwt() ->> 'email' = email);
CREATE POLICY insert_users ON users FOR INSERT WITH CHECK (auth.jwt() ->> 'email' = email);
CREATE POLICY update_users ON users FOR UPDATE USING (auth.jwt() ->> 'email' = email) WITH CHECK (auth.jwt() ->> 'email' = email);
CREATE POLICY delete_users ON users FOR DELETE USING (auth.jwt() ->> 'email' = email);

ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS select_quiz_attempts ON quiz_attempts;
DROP POLICY IF EXISTS insert_quiz_attempts ON quiz_attempts;
DROP POLICY IF EXISTS update_quiz_attempts ON quiz_attempts;
DROP POLICY IF EXISTS delete_quiz_attempts ON quiz_attempts;
CREATE POLICY select_quiz_attempts ON quiz_attempts FOR SELECT USING (auth.jwt() ->> 'email' = user_email);
CREATE POLICY insert_quiz_attempts ON quiz_attempts FOR INSERT WITH CHECK (auth.jwt() ->> 'email' = user_email);
CREATE POLICY update_quiz_attempts ON quiz_attempts FOR UPDATE USING (auth.jwt() ->> 'email' = user_email) WITH CHECK (auth.jwt() ->> 'email' = user_email);
CREATE POLICY delete_quiz_attempts ON quiz_attempts FOR DELETE USING (auth.jwt() ->> 'email' = user_email);

-- Create public view for ranking that does not expose emails
CREATE OR REPLACE VIEW public_ranking AS SELECT nickname, highest_score, created_at FROM users ORDER BY highest_score DESC LIMIT 100;
GRANT SELECT ON public_ranking TO anon;
