-- schema.sql
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique,
  nickname text,
  highest_score int default 0,
  created_at timestamptz default now()
);

create table if not exists questions (
  id serial primary key,
  question_text text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct_option char(1) not null
);

create table if not exists quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_email text not null references users(email) on delete cascade,
  score int not null,
  total_questions int not null default 25,
  created_at timestamptz default now()
);
