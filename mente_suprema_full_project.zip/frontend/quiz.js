// quiz.js - connects to Supabase REST to load questions
const SUPABASE_URL = 'REPLACE_WITH_YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'REPLACE_WITH_YOUR_SUPABASE_ANON_KEY';

let questions = [];
let currentIndex = 0;
let score = 0;

async function fetchQuestions(){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/questions?select=*&limit=25`, {
      headers:{
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
      }
    });
    if(!res.ok) throw new Error('Falha ao buscar perguntas');
    questions = await res.json();
  }catch(e){
    console.error(e);
    // fallback sample questions
    questions = [
      {question_text: '2,4,8,16,?', option_a:'18', option_b:'24', option_c:'32', option_d:'64', correct_option:'C'},
      {question_text: 'Qual figura não pertence: Círculo, Quadrado, Triângulo, Esfera?', option_a:'Círculo', option_b:'Quadrado', option_c:'Triângulo', option_d:'Esfera', correct_option:'D'}
    ];
  }
}

function showQuestion(){
  const q = questions[currentIndex];
  const qb = document.getElementById('question-box');
  qb.innerText = `${currentIndex+1}. ${q.question_text}`;
  const ob = document.getElementById('options-box');
  ob.innerHTML = '';
  const opts = [['A','option_a'],['B','option_b'],['C','option_c'],['D','option_d']];
  opts.forEach(([label,key])=>{
    const d = document.createElement('div');
    d.className = 'option';
    d.innerText = `${label}) ${q[key]}`;
    d.onclick = ()=>{ selectOption(label); };
    ob.appendChild(d);
  });
  document.getElementById('next-button').disabled = true;
}

function selectOption(opt){
  const correct = questions[currentIndex].correct_option.trim().toUpperCase();
  if(opt === correct) score++;
  currentIndex++;
  if(currentIndex < questions.length){
    showQuestion();
  } else {
    showResult();
  }
}

function showResult(){
  document.getElementById('quizContainer').style.display='none';
  const rc = document.getElementById('resultContainer');
  const qi = Math.round((score / questions.length) * 100 + 70); // crude mapping
  rc.style.display='block';
  rc.innerHTML = `<h2>Resultado</h2><p>Nome: ${document.getElementById('playerName').value || 'Anônimo'}</p><p>Pontuação: ${score} / ${questions.length}</p><p>QI estimado: ${qi}</p>`;
  // Optionally: save attempt to Supabase via REST if you have a service role or via backend.
}

document.getElementById('startBtn').addEventListener('click', async ()=>{
  const name = document.getElementById('playerName').value.trim();
  if(!name){ alert('Digite seu nome'); return; }
  await fetchQuestions();
  document.getElementById('prestart').style.display='none';
  document.getElementById('quizContainer').style.display='block';
  showQuestion();
});
