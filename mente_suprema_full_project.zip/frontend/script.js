document.getElementById('year').innerText = new Date().getFullYear();
// simple interactions for V1
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>{}));
